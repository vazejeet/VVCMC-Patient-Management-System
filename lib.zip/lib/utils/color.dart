

import 'package:flutter/material.dart';

class Appcolor{
  static const Color Primary = Colors.teal;
  static const Color Secondary = Colors.green;
  static const Color pure = Colors.white;
}